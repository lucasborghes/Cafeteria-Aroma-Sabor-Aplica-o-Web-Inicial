# Cafeteria Aroma & Sabor — Aplicação Web

Este projeto faz parte do Projeto Integrador II – UFMS Digital.

## 🚀 Tecnologias
- HTML5
- CSS3
- Bootstrap 5

## 📁 Estrutura
- index.html
- README.md

## ▶️ Como abrir
Basta abrir o arquivo `index.html` em qualquer navegador.

